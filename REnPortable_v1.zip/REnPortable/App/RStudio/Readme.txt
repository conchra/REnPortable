RStudio Desktop Open Source files go here (tested with version 1.1.453). 
Download the zipped files from https://www.rstudio.com/products/rstudio/download/
