.Rprofile includes and R environment variable called "BINPREF" used by Rtools
Included based on: https://github.com/stan-dev/rstan/wiki/Installing-RStan-on-Windows
