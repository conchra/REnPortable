Makevars is used by Rtools to build custome packages.
Included based on: https://github.com/stan-dev/rstan/wiki/Installing-RStan-on-Windows
